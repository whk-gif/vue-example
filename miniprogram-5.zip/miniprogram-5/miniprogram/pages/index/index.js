//index.js
const deviceInfoURL = "https://api.heclouds.com/devices/" + 576498633
const getDataStreamURL = "https://api.heclouds.com/devices/" + 576498633 + "/datastreams"
const sendCommandURL = "https://api.heclouds.com/cmds"
Page({
  data:{
    name:'开灯',
    tell:true,
    LEDlogo:'/images/close.png',
  },
  change:function(e){
    if(this.data.tell){
      this.setData({
        name: '关灯',
        tell:false,
        LEDlogo:'/images/open.png',
      })
    }
    else{
      this.setData({
        name:'开灯',
        tell:true,
        LEDlogo:'/images/close.png',
      })
    }
  },
  onLoad: function (options) {
  },
  onPullDownRefresh:function(){
    wx.showNavigationBarLoading() 
    setTimeout(function () {

      // complete

      wx.hideNavigationBarLoading() //完成停止加载

      wx.stopPullDownRefresh() //停止下拉刷新

    }, 1500);
  },
  getDeviceInfo:function(that) {
    //查看设备连接状态，并刷新按钮状态
    wx.request({
      url: deviceInfoURL,
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        "api-key": 'So = pFHatlf6sG5a6dKNK3wW106Q =',
      },
      success(res) {
        // console.log(res)
        if (res.data.data.online) {
          console.log("设备已经连接")
          deviceInit(that)//初始化按钮
          deviceConnected = true
        } else {
          console.log("设备还未连接")
          deviceConnected = false
        }
      },
      fail(res) {
        console.log("请求失败")
        deviceConnected = false
      },
      complete() {
        if (deviceConnected) {
          that.setData({ deviceConnected: true })
        } else {
          that.setData({ deviceConnected: false })
        }
      }
    })
  },
  deviceInit:function(that) {
    console.log("开始初始化按钮")
  //初始化各个硬件的状态
  wx.request({
      url: getDataStreamURL,
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        "api-key": 'So = pFHatlf6sG5a6dKNK3wW106Q =',
      },
      data: {

      },
      success(res) {
        console.log(res)
        for (var i = 0; i < res.data.data.length; i++) {
          var info = res.data.data[i]

          switch (info.id) {
            case "Blue_Led":
              if (info.current_value == 1) {
                that.setData({ blue_checked: true })
              } else {
                that.setData({ blue_checked: false })
              }
              break
            case "Beep":
              if (info.current_value == 1) {
                that.setData({ beep_checked: true })
              } else {
                that.setData({ beep_checked: false })
              }
              break
            case "Red_Led":
              if (info.current_value == 1) {
                that.setData({ red_checked: true })
              } else {
                that.setData({ red_checked: false })
              }
              break
            case "Tempreture":
              break
            case "Yellow_Led":
              if (info.current_value == 1) {
                that.setData({ yellow_checked: true })
              } else {
                that.setData({ yellow_checked: false })
              }
              break
            case "Green_Led":
              if (info.current_value == 1) {
                that.setData({ green_checked: true })
              } else {
                that.setData({ green_checked: false })
              }
              break
            case "Humidity":
              break
          }
        }
      }
    })
  },
  controlLED:function(hardware_id, switch_value) {

    console.log("发送命令：" + hardware_id + ":" + switch_value)
  //按钮发送命令控制硬件
  wx.request({
    url: sendCommandURL + "?device_id=" + 576498633,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        "api-key": apikey
      },

      data: hardware_id + ":" + switch_value,
      success(res) {
        console.log("控制成功")
        console.log(res)
      }
    })
  }
})
